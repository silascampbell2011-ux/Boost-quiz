# Boost & Quiz — 3D Arena Update

A Rocket League-inspired browser practice game with a perspective 3D-style arena, jumping, double-jump aerial touches, aerial boost, and air-roll controls. The original study-note quiz and APK workflow remain included.

## Controls
- **Keyboard:** WASD / arrows to drive and steer, Shift to boost, Space to jump (tap again for a second jump), Q/E to air-roll.
- **Controller:** left stick to steer, RT/LT to accelerate/reverse, B/RB to boost, A to jump/double-jump, stick vertical input for air control.
- Jump, then hold boost while airborne to gain extra height. Use the second jump for an aerial touch.

## Build the APK
1. Push this folder to a GitHub repository on branch `main`.
2. Open the repository's **Actions** tab and wait for **Build APK** to finish.
3. Download the `boost-quiz-apk` artifact and unzip it.
4. Install `app-debug.apk` on your Android device.

The game is in `www/index.html`. The arena and mechanics run locally in canvas; no external 3D library is required.
